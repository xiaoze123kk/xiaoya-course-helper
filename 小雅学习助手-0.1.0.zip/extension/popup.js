'use strict';
const $ = id => document.getElementById(id);
let tab;
const defaults = { rate: 2, documentSeconds: 60, background: true, muted: false, recursive: true };
async function render() {
  const run = (await chrome.storage.session.get('xiaoyaRun')).xiaoyaRun;
  $('count').textContent = `${run?.completed?.length || 0} 项`;
  $('status').textContent = run ? `${run.tabId !== tab?.id ? '其他标签页：' : ''}${run.status || '等待页面响应…'}` : '尚未开始';
  $('logs').replaceChildren(...(run?.logs || []).slice(-6).reverse().map(entry => {
    const li = document.createElement('li');
    li.textContent = `${new Date(entry.time).toLocaleTimeString('zh-CN')} ${entry.text}`;
    return li;
  }));
}
async function initialize() {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const options = { ...defaults, ...(await chrome.storage.local.get('options')).options };
  $('rate').value = options.rate;
  $('seconds').value = options.documentSeconds;
  for (const key of ['background', 'muted', 'recursive']) $(key).checked = options[key];
  await render();
}
$('start').addEventListener('click', async () => {
  $('start').disabled = true;
  try {
    const seconds = Number($('seconds').value);
    if (!Number.isFinite(seconds) || seconds < 10 || seconds > 3600) throw new Error('课件停留时间需为 10–3600 秒。');
    const options = { rate: Number($('rate').value), documentSeconds: seconds,
      background: $('background').checked, muted: $('muted').checked, recursive: $('recursive').checked };
    await chrome.storage.local.set({ options });
    const result = await chrome.runtime.sendMessage({ type: 'start', tabId: tab?.id, options });
    if (result?.error) throw new Error(result.error);
    await render();
  } catch (error) { $('status').textContent = error.message; }
  finally { $('start').disabled = false; }
});
$('stop').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'stop', tabId: tab?.id });
  await render();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'session' && changes.xiaoyaRun) void render();
});
initialize().catch(error => { $('status').textContent = error.message; });

'use strict';
const $ = id => document.getElementById(id);
let tab;
const defaults = { rate: 2, background: true, muted: false, recursive: true };
async function render() {
  const run = (await chrome.storage.session.get('xiaoyaRun')).xiaoyaRun;
  $('count').textContent = `${run?.completed?.length || 0} 项`;
  $('status').textContent = run ? `${run.tabId !== tab?.id ? '其他标签页：' : ''}${run.status || '等待页面响应…'}` : '尚未开始';
  $('task-count').textContent = `${run?.tasks?.length || 0} 项`;
  $('tasks').replaceChildren(...(run?.tasks || []).map(task => {
    const li = document.createElement('li');
    li.textContent = `${task.course} / ${task.name}`;
    return li;
  }));
  $('logs').replaceChildren(...(run?.logs || []).slice(-6).reverse().map(entry => {
    const li = document.createElement('li');
    li.textContent = `${new Date(entry.time).toLocaleTimeString('zh-CN')} ${entry.text}`;
    return li;
  }));
}
async function initialize() {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const options = { ...defaults, ...(await chrome.storage.local.get('options')).options };
  $('rate').value = options.rate;
  for (const key of ['background', 'muted', 'recursive']) $(key).checked = options[key];
  await render();
}
async function command(type) {
  $('start').disabled = true;
  $('scan').disabled = true;
  try {
    const options = { rate: Number($('rate').value),
      background: $('background').checked, muted: $('muted').checked, recursive: $('recursive').checked };
    await chrome.storage.local.set({ options });
    const result = await chrome.runtime.sendMessage({ type, tabId: tab?.id, options });
    if (result?.error) throw new Error(result.error);
    await render();
  } catch (error) { $('status').textContent = error.message; }
  finally { $('start').disabled = false; $('scan').disabled = false; }
}
$('start').addEventListener('click', () => command('start'));
$('scan').addEventListener('click', () => command('scan'));
$('stop').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'stop', tabId: tab?.id });
  await render();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'session' && changes.xiaoyaRun) void render();
});
initialize().catch(error => { $('status').textContent = error.message; });

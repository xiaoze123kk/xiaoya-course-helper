'use strict';
const KEY = 'xiaoyaRun';
chrome.alarms.create('xiaoya-tick', { periodInMinutes: 0.5 });
// Serialize commands so two tabs cannot acquire the queue simultaneously.
let commands = Promise.resolve();
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (!['get', 'start', 'scan', 'save', 'stop'].includes(message?.type)) return;
  commands = commands.then(async () => {
    const stored = (await chrome.storage.session.get(KEY))[KEY];
    if (message.type === 'get') return { run: stored?.tabId === sender.tab?.id ? stored : null };
    if (message.type === 'start' || message.type === 'scan') {
      const tab = await chrome.tabs.get(message.tabId);
      const url = new URL(tab.url || 'about:blank');
      const home = /^\/app\/jx-web\/mycourse\/?$/.test(url.pathname);
      const resource = /^\/app\/jx-web\/mycourse\/[^/]+\/resource\//.test(url.pathname);
      if (url.origin !== 'https://whut.ai-augmented.com' || (!home && !resource)) {
        throw new Error('请登录小雅并打开“我的课程”首页，或课程资源页面。');
      }
      if (message.type === 'scan' && !home) throw new Error('获取跨课程待办请在“我的课程”首页使用。');
      if (message.type === 'scan' && stored?.enabled) throw new Error('队列正在运行，请先停止再重新获取待办。');
      if (stored?.enabled && stored.tabId !== tab.id) throw new Error('另一个标签页正在运行，请先在那里停止。');
      const run = { tabId: tab.id, id: crypto.randomUUID(), enabled: true,
        mode: home ? 'home' : 'directory', scanOnly: message.type === 'scan', tasks: [], homeFinished: [],
        options: message.options, completed: [], visited: [], stack: [], logs: [], started: Date.now() };
      await chrome.storage.session.set({ [KEY]: run });
      try { await chrome.tabs.sendMessage(tab.id, { type: 'run', run }); }
      catch { await chrome.storage.session.remove(KEY); throw new Error('请刷新小雅页面后重新开始。'); }
      return { ok: true };
    }
    if (message.type === 'save') {
      if (stored?.id === message.run?.id && stored.tabId === sender.tab?.id) {
        await chrome.storage.session.set({ [KEY]: message.run });
      }
      return { ok: true };
    }
    if (message.type === 'stop') {
      if (stored?.tabId === message.tabId) {
        stored.enabled = false;
        await chrome.storage.session.set({ [KEY]: stored });
        await chrome.tabs.sendMessage(stored.tabId, { type: 'halt' }).catch(() => {});
      }
      return { ok: true };
    }
  }).then(reply, error => reply({ error: error.message }));
  return true;
});
chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name !== 'xiaoya-tick') return;
  const run = (await chrome.storage.session.get(KEY))[KEY];
  if (run?.enabled) await chrome.tabs.sendMessage(run.tabId, { type: 'tick' }).catch(() => {});
});
chrome.tabs.onRemoved.addListener(async tabId => {
  const run = (await chrome.storage.session.get(KEY))[KEY];
  if (run?.tabId === tabId) await chrome.storage.session.remove(KEY);
});

'use strict';
const KEY = 'xiaoyaRun';
chrome.alarms.create('xiaoya-tick', { periodInMinutes: 0.5 });
// Serialize commands so two tabs cannot acquire the queue simultaneously.
let commands = Promise.resolve();
async function pageLoaded(tabId) {
  await new Promise((resolve, reject) => {
    let timer;
    const cleanup = () => { clearTimeout(timer); chrome.tabs.onUpdated.removeListener(updated); };
    const updated = (id, change) => {
      if (id === tabId && change.status === 'complete') { cleanup(); resolve(); }
    };
    chrome.tabs.onUpdated.addListener(updated);
    timer = setTimeout(() => { cleanup(); reject(new Error('独立学习标签页加载超时，请检查网络。')); }, 20000);
    chrome.tabs.get(tabId).then(tab => {
      if (tab.status === 'complete') { cleanup(); resolve(); }
    }, error => { cleanup(); reject(error); });
  });
}
async function releasePage(run) {
  if (run?.dedicated) await chrome.tabs.update(run.tabId, { autoDiscardable: true }).catch(() => {});
}
async function connectPage(tabId) {
  let health = await chrome.tabs.sendMessage(tabId, { type: 'health' }).catch(() => null);
  if (health?.protocol !== 4) {
    // Extension reloads don't automatically attach scripts to an already-open page.
    await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', files: ['background-mode.js'] });
    await chrome.scripting.executeScript({ target: { tabId }, files: ['task-timing.js', 'content.js'] });
    health = await chrome.tabs.sendMessage(tabId, { type: 'health' }).catch(() => null);
  }
  if (!health?.ok || health.protocol !== 4) throw new Error('页面脚本连接失败，请刷新小雅首页后重试。');
}
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (!['get', 'start', 'scan', 'save', 'stop'].includes(message?.type)) return;
  commands = commands.then(async () => {
    const stored = (await chrome.storage.session.get(KEY))[KEY];
    if (message.type === 'get') return { run: stored?.tabId === sender.tab?.id ? stored : null };
    if (message.type === 'start' || message.type === 'scan') {
      const tab = await chrome.tabs.get(message.tabId);
      const url = new URL(tab.url || 'about:blank');
      const home = /^\/app\/jx-web\/mycourse\/?$/.test(url.pathname);
      const resource = /^\/app\/jx-web\/mycourse\/[^/]+\/resource\//.test(url.pathname);
      if (url.origin !== 'https://whut.ai-augmented.com' || (!home && !resource)) {
        throw new Error('请登录小雅并打开“我的课程”首页，或课程资源页面。');
      }
      if (message.type === 'scan' && !home) throw new Error('获取跨课程待办请在“我的课程”首页使用。');
      if (message.type === 'scan' && stored?.enabled) throw new Error('队列正在运行，请先停止再重新获取待办。');
      if (stored?.enabled) throw new Error('已有队列正在运行，请先点击停止再重新开始。');
      let studyTab = tab;
      const dedicated = message.type === 'start' && message.options?.background === true;
      try {
        if (dedicated) {
          studyTab = await chrome.tabs.create({ url: tab.url, active: false });
          await chrome.tabs.update(studyTab.id, { autoDiscardable: false });
          await pageLoaded(studyTab.id);
        }
        await connectPage(studyTab.id);
      } catch (error) {
        if (dedicated && studyTab.id !== tab.id) await releasePage({ tabId: studyTab.id, dedicated: true });
        throw error;
      }
      await chrome.storage.session.remove('xiaoyaError');
      const run = { tabId: studyTab.id, sourceTabId: tab.id, dedicated, id: crypto.randomUUID(), enabled: true,
        mode: home ? 'home' : 'directory', scanOnly: message.type === 'scan', tasks: [], homeFinished: [],
        options: message.options, completed: [], visited: [], stack: [], logs: [], started: Date.now() };
      await chrome.storage.session.set({ [KEY]: run });
      try {
        const result = await chrome.tabs.sendMessage(studyTab.id, { type: 'run', run });
        if (!result?.ok) throw new Error('页面未确认接收队列');
      } catch {
        await chrome.storage.session.remove(KEY);
        await releasePage(run);
        throw new Error('页面未接收到启动命令，请刷新小雅首页后重试。');
      }
      return { ok: true };
    }
    if (message.type === 'save') {
      if (stored?.id === message.run?.id && stored.tabId === sender.tab?.id) {
        if (stored.enabled && !message.run.enabled) await releasePage(stored);
        await chrome.storage.session.set({ [KEY]: message.run });
      }
      return { ok: true };
    }
    if (message.type === 'stop') {
      if (stored && (stored.tabId === message.tabId || stored.sourceTabId === message.tabId)) {
        stored.enabled = false;
        await chrome.storage.session.set({ [KEY]: stored });
        await chrome.tabs.sendMessage(stored.tabId, { type: 'halt' }).catch(() => {});
        await releasePage(stored);
      }
      return { ok: true };
    }
  }).then(reply, async error => {
    const failure = { text: error.message, tabId: message.tabId, at: Date.now() };
    await chrome.storage.session.set({ xiaoyaError: failure });
    reply({ error: error.message });
  });
  return true;
});
chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name !== 'xiaoya-tick') return;
  const run = (await chrome.storage.session.get(KEY))[KEY];
  if (run?.enabled) await chrome.tabs.sendMessage(run.tabId, { type: 'tick' }).catch(() => {});
});
chrome.tabs.onRemoved.addListener(async tabId => {
  const run = (await chrome.storage.session.get(KEY))[KEY];
  if (run?.tabId === tabId) await chrome.storage.session.remove(KEY);
});
